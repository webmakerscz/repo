﻿using System.Web;

namespace StiglSite {
    public class Global : HttpApplication {
        protected void Application_Start() {
        }
    }
}
