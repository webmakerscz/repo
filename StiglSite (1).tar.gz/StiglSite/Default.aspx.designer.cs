﻿using System;
using System.Web;
using System.Web.UI;

namespace StiglSite {

    public partial class Default {
        protected System.Web.UI.WebControls.Button button1;
    }
}
